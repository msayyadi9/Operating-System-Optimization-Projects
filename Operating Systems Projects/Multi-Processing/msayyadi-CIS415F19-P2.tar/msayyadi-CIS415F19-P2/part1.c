#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
int ln;

int arg_Counter(char *ln){

    char ln_copy[1000];
    strcpy(ln_copy, ln);
    int words_in_line = 0;
    static char ws[] = " \t\n";
    char *stri_tok = strtok(ln_copy, ws); // 
    while(stri_tok != NULL){
        stri_tok = strtok(NULL, ws);
        words_in_line++;
    }
    return words_in_line;
}

int line_Counter(char *filename){
    FILE *fp = fopen(filename,"r"); // Opens file in read mode

    if(fp == NULL){                 // Exits the program if there is en error with the file
        exit(EXIT_FAILURE);
    }

    // Creates a size_t variable to specify the size for the getline function
    size_t mem_line = 2000;

    char *b_mall = (char *)malloc(sizeof(char)*2000); // MEM
    
    // FILE *fo = fopen(fileOut, "w");
    int lines_in_file = 0;

    while(!feof(fp)){
        getline(&b_mall, &mem_line, fp);
        lines_in_file++;
    }
    free(b_mall);
    fclose(fp);

    return lines_in_file;
}

int main(int argc, char *argv[]) 
{ 
    FILE *fp = fopen(argv[1],"r"); // Opens file in read mode

    if(fp == NULL){
        printf("Error: Unable to open file \n");
        exit(EXIT_FAILURE);
    }

    size_t mem_line = 2000;
    char *b_mall = (char *)malloc(sizeof(char)*2000); // MEM
    ln = line_Counter(argv[1]);
    ln = ln-1;

    printf("%d\n",ln);

    int pidArr[ln];

    int i;
    for(i = 0; i < ln; i++){
        getline(&b_mall, &mem_line, fp);
        int numArgs = arg_Counter(b_mall);
        char *tk = strtok(b_mall, " "); 
        char *wordArr[100];
        
        int idx = 0;
        while(tk != NULL){ 
            size_t leng = strlen(tk);
            
            // Removes "\n" characters
            if (tk[leng - 1] == '\n'){
                tk[leng - 1] = '\0';
            }
            wordArr[idx] = tk;
            tk = strtok(NULL, " ");
            printf("%s\n", wordArr[idx]); 
            idx++;
        }
        wordArr[idx] = NULL;

        pidArr[i] = fork();
        printf("Fork: %d\n", pidArr[i]);

        if(pidArr[i] < 0){
            perror("Fork Error");
        }
        if(pidArr[i] == 0){
            
            printf("Executing child program: %d\n", getpid());
            execvp(wordArr[0], wordArr);
            exit(-1);
        }

        else{
            printf("Parent: %d\n", getpid());
        }
        printf("\n\n\n");
    }

    sleep(2);

    int e;
    for(e = 0; e < ln; e++){
        printf("%d <-- PID\n",pidArr[e]);
        waitpid(pidArr[e],NULL,0);
        printf("DONE PRINTING PID\n");
    }

    free(b_mall);
    fclose(fp);
    return 0; 
} 