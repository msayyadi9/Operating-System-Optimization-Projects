#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]){
	printf("University of %s\n", argv[1]);
	sleep(1);
	printf("%s State University\n", argv[2]);
	sleep(1);
	printf("Portland, %s\n", argv[3]);
	sleep(1);
	printf("States Program Finished\n");
	return 0;
}