#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include <ctype.h>
#include <dirent.h>

int *pidArr;
int idx = 0;
int ln;

// Mason Sayyadi
// Project 2 - Part 4
// CIS 415 

int arg_Counter(char *ln){

    char ln_copy[1000];
    strcpy(ln_copy, ln);
    int words_in_line = 0;
    static char ws[] = " \t\n";
    char *stri_tok = strtok(ln_copy, ws); // 

    while(stri_tok != NULL){
        stri_tok = strtok(NULL, ws);
        words_in_line++;
    }
    return words_in_line;
}

int line_Counter(char *filename){
    FILE *fp = fopen(filename,"r"); // Opens file in read mode

    // Error checking
    if(fp == NULL){
        exit(EXIT_FAILURE);
    }

    // Creates a size_t variable to specify the size for the getline function
    size_t mem_line = 2000;
    char *b_mall = (char *)malloc(sizeof(char)*2000);
    int lines_in_file = 0;

    while(!feof(fp)){
        getline(&b_mall, &mem_line, fp);
        lines_in_file++;
    }

    free(b_mall);
    fclose(fp);

    return lines_in_file;
}

char *pstat(int tgid, char *pstat, int pstat_len) {
    
    char pt[40], ln[100], *p;
    FILE* statusf;

    // Open filepath to the /proc folder of PID
    snprintf(pt, 40, "/proc/%d/status", tgid);
    statusf = fopen(pt, "r");
    if(!statusf){
        char *ex = "N/A";
        return ex;
    }
    char *word;
    word = malloc(sizeof(char)*100);
    while(fgets(ln, 100, statusf)) {
        if(strncmp(ln, pstat, pstat_len) == 0){
            size_t l = strlen(p);
            
            if(p[l-1] == '\n'){
                p[l-1] = '\0';
            }
            strcpy(word,p);
            break;
        }
        // Ignore "State:" and whitespace
        p = ln + 7;
    }

    fclose(statusf);
    return word;
}

void setTimer(){
    // Timer that contains quantum time
    // Q-Time set to 1 second
    struct timeval t;
    t.tv_sec = 1;
    t.tv_usec = 0;

    struct itimerval itv;
    itv.it_interval = t;
    itv.it_value = t;

    setitimer(ITIMER_REAL, &itv, NULL);
}

void handler(int sig){
    printf("RECEIVED SIGUSR1:\n Child Process: %d - Received Signal: %d\n", getpid(), sig);
}

void signaler(pid_t pid, int sig){
    printf("%d PID :: Signal %d\n", pid, sig);
    kill(pid, sig);
}

int checkLiving(){
    int i;
    for(i = 0; i < ln; i++){
       if(kill(pidArr[i],0) != 0){
            return 1;
        } 
    }
    return 0;
}

void alarmHandler(int sig){

    printf("RECEIVED ALRM:\nChild Process: %d - Received Signal: %d\n", getpid(), sig);

    pid_t pid;
    // Checks to see if processes are alive 
    // Haults the function
    while((pid = waitpid(0, NULL, WNOHANG)) > 0);
    for(; idx < ln; idx++) {
        if (kill(pidArr[idx], 0) == 0) {
            fprintf(stderr, "Stopping: %d\n", pidArr[idx]);
            kill (pidArr[idx], SIGSTOP);
            idx++;
            break;
        }
    }

    // Returns to the front of the process pool
    if(idx == ln){
        idx = 0;
    }

    // Continues the haulted function
    for(; idx < ln; idx++) {
        if(kill(pidArr[idx], 0) == 0){
            fprintf(stderr, "Continuing: %d\n", pidArr[idx]);
            kill (pidArr[idx], SIGCONT);
            break;
        }
    }
    setTimer();
}

int main(int argc, char *argv[]) 
{ 
    FILE *fp = fopen(argv[1],"r"); // Opens file in read mode

    if(fp == NULL){                 // Exits the program if there is en error with the file
        printf("Error: Unable to open file\n");
        exit(EXIT_FAILURE);
    }

    size_t mem_line = 2000;
    char *b_mall = (char *)malloc(sizeof(char)*2000); // MEM
    ln = line_Counter(argv[1]);
    ln = ln-1;
    pidArr = malloc(sizeof(int) * ln);

    // Assigns SIGUSR1 to a handler
    signal(SIGUSR1, handler);

    // Signal Sets
    sigset_t new_set;               // Creates a new signal set
    sigemptyset (&new_set);         // Empties set of signals
    sigaddset(&new_set, SIGUSR1);   // Adds SIGUSR1 to list of signals in set

    int i;
    int sig;

    for(i = 0; i < ln; i++){
        getline(&b_mall, &mem_line, fp);
        int numArgs = arg_Counter(b_mall);
        char *tk = strtok(b_mall, " "); 
        char *wordArr[100];
        
        int idx = 0;
        while(tk != NULL){ 

            // Gets length of tokenized word
            size_t leng = strlen(tk);

            // Removes "\n" characters
            if (tk[leng - 1] == '\n'){
                tk[leng - 1] = '\0';
            }

            // Processes and arguments are stored in wordArr
            wordArr[idx] = tk;
            tk = strtok(NULL, " ");
            printf("%s\n", wordArr[idx]); 
            idx++;
        }

        wordArr[idx] = NULL;

        pidArr [i] = fork();
        printf("Fork: %d\n", (int)pidArr[i]);

        // If there is an error with fork
        if(pidArr [i] < 0){
            perror("Fork Error");
        }

        // Executes child program
        if(pidArr [i] == 0){
            printf("Executing child program: %d\n", getpid());
            sigwait(&new_set, &sig);
            execvp(wordArr[0], wordArr);
            exit(-1);
        }
        // Parent continues to run in loop
        else{
            printf("Running parent - PID: %d\n", getpid());
        }
        printf("\n\n\n");
    }
    
    // Waits for all child process to be in a state of waiting
    sleep(2);

    // Assigns the alarm handler to SIGALRM
    signal(SIGALRM, alarmHandler);

    // Prints the PID array
    fprintf(stderr,"{");
    for(i = 0; i < ln; i++)
        fprintf(stderr,"%d ,", pidArr[i]);
        fprintf(stderr,"\b}\n");

    // Sends the SIGUSR1 signal to all child processes
    // Continues all child processes    
    for(; idx < ln; idx++){
        signaler(pidArr[idx], SIGUSR1);
    }
    
    // Sends the SIGSTOP signal to all child processes
    for(idx = 0; idx < ln; idx++){
        signaler(pidArr[idx], SIGSTOP);
    }


    setTimer();
    pid_t pid;

    system("clear");

    int ct = 0;
    int v;

    int parent_pid = pidArr[0];
    parent_pid = parent_pid - 1;

    for(v = 0; v < 20; v++){
        int m;
        printf("(Running for 20 seconds)\n");
        printf("Elapsed Time (Seconds): %d\n",ct);
        printf("PID: %d   Name: %s   State: %s   SigQ: %s\n", parent_pid, pstat(parent_pid, "Name:", 5), pstat(parent_pid, "State:", 6), pstat(parent_pid, "SigQ:", 5));
        for(m = 0; m < ln; m++){
            printf("PID: %d   Name: %s   State: %s   SigQ: %s\n", pidArr[m], pstat(pidArr[m], "Name:", 5), pstat(pidArr[m], "State:", 6), pstat(pidArr[m], "SigQ:", 5));
        }
        sleep(1);
        system("clear");
        ct++;
    }

    while((pid = waitpid(0, NULL, 0)) > 0){
        fprintf(stderr, "%d Completed\n", (int)pid);
    }

    // Frees variables
    free(pidArr);
    free(b_mall);
    fclose(fp);
    return 0; 
} 